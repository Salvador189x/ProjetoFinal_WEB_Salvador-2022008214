import { useState } from "react";
import Login from "./pages/Login";
import Appointments from "./pages/Appointments";

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));

  if (!token) return <Login onLogin={setToken} />;

  return <Appointments token={token} onLogout={() => setToken(null)} />;
}
