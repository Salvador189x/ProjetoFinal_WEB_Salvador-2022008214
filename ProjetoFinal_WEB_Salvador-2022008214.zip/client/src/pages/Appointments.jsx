import { useEffect, useState } from "react";
import {
  getAppointments,
  createAppointment,
  updateAppointment,
  deleteAppointment,
} from "../services/api";
import "../App.css";

export default function Appointments({ token, onLogout }) {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  // form
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(""); // "2026-01-20T14:00"
  const [status, setStatus] = useState("pending");
  const [notes, setNotes] = useState("");

  // edit
  const [editingId, setEditingId] = useState(null);

  async function load() {
    try {
      setLoading(true);
      const data = await getAppointments(token, { page: 1, limit: 50 });
      setAppointments(data.appointments || []);
    } catch (e) {
      alert(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function resetForm() {
    setTitle("");
    setDate("");
    setStatus("pending");
    setNotes("");
    setEditingId(null);
  }

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      const payload = {
        title,
        date: date ? new Date(date).toISOString() : undefined,
        status,
        notes,
      };

      if (editingId) {
        await updateAppointment(token, editingId, payload);
      } else {
        await createAppointment(token, payload);
      }

      resetForm();
      await load();
    } catch (e) {
      alert(e.message);
    }
  }

  function handleEdit(a) {
    setEditingId(a._id);
    setTitle(a.title || "");
    setStatus(a.status || "pending");
    setNotes(a.notes || "");

    // ISO -> input datetime-local
    const d = a.date ? new Date(a.date) : null;
    if (d) {
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const hh = String(d.getHours()).padStart(2, "0");
      const mi = String(d.getMinutes()).padStart(2, "0");
      setDate(`${yyyy}-${mm}-${dd}T${hh}:${mi}`);
    } else {
      setDate("");
    }
  }

  async function handleDelete(id) {
    if (!confirm("Apagar este agendamento?")) return;
    try {
      await deleteAppointment(token, id);
      await load();
    } catch (e) {
      alert(e.message);
    }
  }

  function formatDate(iso) {
    if (!iso) return "-";
    return new Date(iso).toLocaleString();
  }

  return (
    <div className="page">
      <div className="container">
        <div className="topbar">
          <h1 className="title">Agendamentos</h1>

          <button
            className="btn"
            onClick={() => {
              localStorage.removeItem("token");
              onLogout();
            }}
            type="button"
          >
            Sair
          </button>
        </div>

        {/* FORM */}
        <div className="card">
          <form className="form" onSubmit={handleSubmit}>
            <div className="field">
              <span className="label">Título</span>
              <input
                className="input"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Consulta de retorno"
              />
            </div>

            <div className="grid2">
              <div className="field">
                <span className="label">Data/Hora</span>
                <input
                  className="input"
                  type="datetime-local"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>

              <div className="field">
                <span className="label">Status</span>
                <select
                  className="select"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option value="pending">pending</option>
                  <option value="confirmed">confirmed</option>
                  <option value="done">done</option>
                  <option value="canceled">canceled</option>
                </select>
              </div>
            </div>

            <div className="field">
              <span className="label">Notas</span>
              <textarea
                className="textarea"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Observações..."
                rows={3}
              />
            </div>

            <div className="btnRow">
              <button className="btn btnPrimary" type="submit">
                {editingId ? "Salvar alterações" : "Criar agendamento"}
              </button>

              {editingId && (
                <button className="btn" type="button" onClick={resetForm}>
                  Cancelar edição
                </button>
              )}
            </div>
          </form>
        </div>

        {/* LISTA */}
        <div className="list">
          {loading ? (
            <div className="card">
              <div className="meta">Carregando...</div>
            </div>
          ) : appointments.length === 0 ? (
            <div className="card">
              <div className="meta">Nenhum agendamento ainda.</div>
            </div>
          ) : (
            appointments.map((a) => (
              <div key={a._id} className="card item">
                <div>
                  <p className="itemTitle">{a.title || "(sem título)"}</p>
                  <div className="meta">{formatDate(a.date)}</div>
                  <div className="meta">status: {a.status}</div>

                  {a.notes ? <div className="notes">{a.notes}</div> : null}
                </div>

                <div className="btnRow">
                  <button className="btn" type="button" onClick={() => handleEdit(a)}>
                    Editar
                  </button>
                  <button
                    className="btn btnDanger"
                    type="button"
                    onClick={() => handleDelete(a._id)}
                  >
                    Apagar
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
