import { useState } from "react";
import { login } from "../services/api";
import "../App.css";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const data = await login(email, password);
      localStorage.setItem("token", data.token);
      onLogin(data.token);
    } catch (e) {
      alert(e.message);
    }
  }

  return (
    <div className="loginWrap">
      <form className="loginCard form" onSubmit={handleSubmit}>
        <h2 className="loginTitle">Login</h2>

        <div className="field">
          <span className="label">Email</span>
          <input className="input" value={email} onChange={(e)=>setEmail(e.target.value)} />
        </div>

        <div className="field">
          <span className="label">Senha</span>
          <input className="input" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
        </div>

        <button className="btn btnPrimary" type="submit">Entrar</button>
      </form>
    </div>
  );
}
