const API_URL = "http://localhost:3001";

async function request(path, { method = "GET", token, body } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const msg = data?.message || "Erro na requisição";
    throw new Error(msg);
  }

  return data;
}

// AUTH
export async function login(email, password) {
  return request("/auth/login", { method: "POST", body: { email, password } });
}

// APPOINTMENTS
export async function getAppointments(token, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const url = qs ? `/appointments?${qs}` : "/appointments";
  return request(url, { token });
}

export async function createAppointment(token, payload) {
  return request("/appointments", { method: "POST", token, body: payload });
}

export async function updateAppointment(token, id, payload) {
  return request(`/appointments/${id}`, { method: "PUT", token, body: payload });
}

export async function deleteAppointment(token, id) {
  return request(`/appointments/${id}`, { method: "DELETE", token });
}
