require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const testRoutes = require("./routes/testRoutes");
const appointmentRoutes = require("./routes/appointmentRoutes");



const app = express();

app.use(cors());
app.use(express.json());
app.use("/test", testRoutes);
app.use("/appointments", appointmentRoutes);



connectDB();

app.use("/auth", authRoutes);

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
