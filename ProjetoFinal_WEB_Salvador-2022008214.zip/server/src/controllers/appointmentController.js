const Appointment = require("../models/Appointment");
const { createSchema, updateSchema } = require("../validators/appointmentValidator");

/**
 * Regras:
 * - user comum: só acessa os próprios agendamentos (req.user.id)
 * - admin: pode ver/alterar tudo
 */

function isAdmin(req) {
  return req.user?.role === "admin";
}

// CREATE - criar agendamento
exports.create = async (req, res) => {
  try {
    // ✅ valida antes de tudo
    const { error, value } = createSchema.validate(req.body, { abortEarly: false });
    if (error) {
      return res.status(400).json({
        message: "Dados inválidos",
        details: error.details.map((d) => d.message),
      });
    }

    const { title, date, status, notes } = value;

    const appointment = await Appointment.create({
      user: req.user.id,
      title,
      date,
      status: status || "pending",
      notes: notes || "",
    });

    return res.status(201).json({ message: "Agendamento criado", appointment });
  } catch (error) {
    return res.status(500).json({ message: "Erro ao criar", error: error.message });
  }
};


exports.createAsAdmin = async (req, res) => {
  try {
    // precisa receber userId + dados do agendamento
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ message: "Informe userId" });
    }

    // valida os dados do agendamento (title, date, status, notes)
    const { error, value } = createSchema.validate(req.body, { abortEarly: false });
    if (error) {
      return res.status(400).json({
        message: "Dados inválidos",
        details: error.details.map((d) => d.message),
      });
    }

    const { title, date, status, notes } = value;

    const appointment = await Appointment.create({
      user: userId,
      title,
      date,
      status: status || "pending",
      notes: notes || "",
    });

    return res.status(201).json({
      message: "Agendamento criado pelo admin",
      appointment,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Erro ao criar (admin)",
      error: error.message,
    });
  }
};


// READ ALL - listar agendamentos
exports.list = async (req, res) => {
  try {
    const filter = isAdmin(req) ? {} : { user: req.user.id };

    // ✅ filtro opcional por data (YYYY-MM-DD)
    const { date } = req.query;

    if (date) {
      // pega o dia inteiro: 00:00 até 23:59:59.999
      const start = new Date(date + "T00:00:00.000Z");
      const end = new Date(date + "T23:59:59.999Z");
      filter.date = { $gte: start, $lte: end };
    }

    // ✅ paginação
    const page = Math.max(parseInt(req.query.page || "1", 10), 1);
    const limit = Math.max(parseInt(req.query.limit || "10", 10), 1);

    const skip = (page - 1) * limit;

    const [appointments, total] = await Promise.all([
    Appointment.find(filter)
        .populate("user", "name email role")
        .sort({ date: 1 })
        .skip(skip)
        .limit(limit),
    Appointment.countDocuments(filter),
    ]);

    return res.json({
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
    appointments,
    });


  } catch (error) {
    return res.status(500).json({ message: "Erro ao listar", error: error.message });
  }
};


// READ ONE - pegar 1 agendamento
exports.getById = async (req, res) => {
  try {
    const { id } = req.params;

    const appointment = await Appointment.findById(id).populate(
      "user",
      "name email role"
    );

    if (!appointment) {
      return res.status(404).json({ message: "Agendamento não encontrado" });
    }

    // user comum só pode ver o próprio
    if (!isAdmin(req) && appointment.user._id.toString() !== req.user.id) {
      return res.status(403).json({ message: "Sem permissão" });
    }

    return res.json({ appointment });
  } catch (error) {
    return res.status(500).json({ message: "Erro ao buscar", error: error.message });
  }
};

// UPDATE - atualizar agendamento
exports.update = async (req, res) => {
  try {
    // ✅ valida antes de tudo (e obriga ao menos 1 campo)
    const { error, value } = updateSchema.validate(req.body, { abortEarly: false });
    if (error) {
      return res.status(400).json({
        message: "Dados inválidos",
        details: error.details.map((d) => d.message),
      });
    }

    const { id } = req.params;

    const appointment = await Appointment.findById(id);

    if (!appointment) {
      return res.status(404).json({ message: "Agendamento não encontrado" });
    }

    // user comum só pode editar o próprio
    if (!isAdmin(req) && appointment.user.toString() !== req.user.id) {
      return res.status(403).json({ message: "Sem permissão" });
    }

    const { title, date, status, notes } = value;

    if (title !== undefined) appointment.title = title;
    if (date !== undefined) appointment.date = date;
    if (status !== undefined) appointment.status = status;
    if (notes !== undefined) appointment.notes = notes;

    await appointment.save();

    return res.json({ message: "Agendamento atualizado", appointment });
  } catch (error) {
    return res.status(500).json({ message: "Erro ao atualizar", error: error.message });
  }
};

// DELETE - apagar agendamento
exports.remove = async (req, res) => {
  try {
    const { id } = req.params;

    const appointment = await Appointment.findById(id);

    if (!appointment) {
      return res.status(404).json({ message: "Agendamento não encontrado" });
    }

    // user comum só pode apagar o próprio
    if (!isAdmin(req) && appointment.user.toString() !== req.user.id) {
      return res.status(403).json({ message: "Sem permissão" });
    }

    await appointment.deleteOne();

    return res.json({ message: "Agendamento removido" });
  } catch (error) {
    return res.status(500).json({ message: "Erro ao remover", error: error.message });
  }
};
