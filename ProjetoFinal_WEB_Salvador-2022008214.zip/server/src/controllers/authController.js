const User = require("../models/User");
const bcrypt = require("bcrypt");

// Cadastro de usuário
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // 1️⃣ Verificar se todos os campos vieram
    if (!name || !email || !password) {
      return res.status(400).json({ message: "Preencha todos os campos" });
    }

    // 2️⃣ Verificar se usuário já existe
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: "Usuário já existe" });
    }

    // 3️⃣ Criptografar a senha
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // 4️⃣ Criar usuário
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
    });

    // 5️⃣ Resposta
    res.status(201).json({
      message: "Usuário criado com sucesso",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Erro no servidor", error: error.message });
  }
};

const jwt = require("jsonwebtoken");

exports.me = async (req, res) => {
  return res.json({ user: req.user });
};


// Login de usuário
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // 1️⃣ Verificar campos
    if (!email || !password) {
      return res.status(400).json({ message: "Informe email e senha" });
    }

    // 2️⃣ Buscar usuário
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Usuário não encontrado" });
    }

    // 3️⃣ Comparar senha
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Senha incorreta" });
    }

    // 4️⃣ Gerar token
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    // 5️⃣ Resposta
    res.json({
      message: "Login realizado com sucesso",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Erro no login", error: error.message });
  }
};


exports.me = async (req, res) => {
  return res.json({ user: req.user });
};
