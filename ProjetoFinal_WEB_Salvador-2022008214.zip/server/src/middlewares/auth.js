const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  const authHeader = req.headers.authorization;

  // Verifica se tem token
  if (!authHeader) {
    return res.status(401).json({ message: "Token não informado" });
  }

  const token = authHeader.split(" ")[1];

  try {
    // Decodifica token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Salva dados do usuário na requisição
    req.user = decoded;

    next();
  } catch (error) {
    return res.status(401).json({ message: "Token inválido" });
  }
};
