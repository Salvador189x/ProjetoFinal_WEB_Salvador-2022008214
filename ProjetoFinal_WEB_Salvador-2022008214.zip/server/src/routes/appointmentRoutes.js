const express = require("express");
const router = express.Router();

const auth = require("../middlewares/auth");
const appointmentController = require("../controllers/appointmentController");
const admin = require("../middlewares/admin");

router.post("/admin/create", admin, appointmentController.createAsAdmin);


// tudo aqui é protegido
router.use(auth);

// CRUD

router.post("/", appointmentController.create);      // CREATE
router.get("/", appointmentController.list);         // READ ALL
router.get("/:id", appointmentController.getById);   // READ ONE
router.put("/:id", appointmentController.update);    // UPDATE
router.delete("/:id", appointmentController.remove); // DELETE

module.exports = router;
