const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth");
const admin = require("../middlewares/admin");

// rota só para usuário logado
router.get("/private", auth, (req, res) => {
  res.json({
    message: "Você está autenticado",
    user: req.user,
  });
});

// rota só para admin
router.get("/admin", auth, admin, (req, res) => {
  res.json({ message: "Bem-vindo, administrador" });
});

module.exports = router;
