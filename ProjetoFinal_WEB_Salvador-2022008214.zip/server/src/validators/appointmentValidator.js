const Joi = require("joi");

exports.createSchema = Joi.object({
  title: Joi.string().min(2).max(100).required(),
  date: Joi.date().iso().required(),
  status: Joi.string().valid("pending", "confirmed", "canceled").optional(),
  notes: Joi.string().allow("").max(500).optional(),
});

exports.updateSchema = Joi.object({
  title: Joi.string().min(2).max(100).optional(),
  date: Joi.date().iso().optional(),
  status: Joi.string().valid("pending", "confirmed", "canceled").optional(),
  notes: Joi.string().allow("").max(500).optional(),
}).min(1); // obriga enviar pelo menos 1 campo no update
